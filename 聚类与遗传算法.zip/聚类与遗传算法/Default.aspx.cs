﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Data;

public partial class _Default : System.Web.UI.Page
{

    /// <summary>
    /// 聚类的数量
    /// </summary>
    private static readonly int k =5;

    protected void Page_Load(object sender, EventArgs e)
    {
        Cluster();
    }
    //带载货限制的聚类分析，用于调配运力，可多车，3-6车，找出最恰当的配车数，给出分析方案。这是否为一个动态方法？
    private static readonly double[,] coords = new double[,]
    {
           {1,26.73686,112.68021,500},{2,26.71877,112.729872,100},{3,26.909946,112.906376,110},{4,26.601864,112.579668,101},
            {5,26.677208,112.770648,123},{6,26.845006,112.35513,180},{7,26.67106,112.880399,160},{8,26.767216,112.765585,91},
            {9,26.714055,112.903732,92},{10,26.726089,113.010976,89},{11,26.831075,113.004152,60},
            {12,26.876414,112.494423,80},{13,26.876633,112.753117,115},{14,26.835662,112.869332,111},
            {15,26.738194,112.312539,120},{16,26.851764,112.254426,118},{17,26.848019,112.296661,80},
            {18,26.698604,112.36721,144},{19,26.712843,112.465673,103},{20,26.77352,112.588816,66},
            {21,26.59786,112.499246,98},{22,26.58933,112.414927,125},{23,26.932302,112.72124,108},{24,26.702177,112.823173,126}
    };
    
    /// <summary>
    /// 
    /// </summary>
    public  void Cluster()
    {
        Point[] points = GetPoints(); //获取原始数据点
        PointF[] means = new PointF[k]; //当前的聚类中心
        PointF[] prevMeans = new PointF[k]; //之前的聚类中心
        int[] pointAssigns = new int[points.Length]; //每个点所属的类

        InitMeans(points, k, means); //随机选k个点作为聚类中心
        PrintInit(points, k, means); //打印初始数据

        int iter = 0; //迭代次数(iteration times)
        while (true)
        {
            Classify(points, k, means, pointAssigns); //将每个点与各个聚类中心对比进行归类划分
            int conv = 0;
            for (int j = 0; j < k; j++)
            {
                means[j] = CalcMeans(points, pointAssigns, j); //重新计算聚类中心
                if (Compare(means[j], prevMeans[j]))
                    conv++;
                else
                    prevMeans[j] = means[j];
            }
            if (conv == k) //新旧聚类中心一样表示该聚类已收敛至平衡
            {
                break;
            }

            iter++;
            PrintIter(points, k, means, pointAssigns, iter); //打印迭代数据
        }
    }

    /// <summary>
    /// 初始化点数组(根据自定义坐标)
    /// </summary>
    private static Point[] GetPoints()
    {
        int len = coords.GetLength(0);
        Point[] points = new Point[len];
        for (int i = 0; i < len; i++)
        {
            points[i] = new Point((int)(coords[i, 1]  * 100000.0), (int)(coords[i, 2] * 100000.0));
        }
        return points;
    }

    /// <summary>
    /// 随机选k个点作为聚类中心
    /// </summary>
    private static void InitMeans(Point[] points, int k, PointF[] means)
    {
        Random random = new Random();
        for (int i = 0; i < k; i++)
        {
            means[i] = points[random.Next(points.Length)];
        }
    }

    /// <summary>
    /// 将每个点与各个聚类中心对比进行归类划分
    /// </summary>
    private static void Classify(Point[] points, int k, PointF[] means, int[] pointAssigns)
    {
        for (int i = 0; i < points.Length; i++)
        {
            double minDist = double.MaxValue; //最短距离
            for (int j = 0; j < k; j++)
            {
                double dist = Distance(points[i], means[j]);
                if (dist < minDist)
                {
                    minDist = dist;
                    pointAssigns[i] = j;
                }
            }
            //Console.WriteLine("{0}归入类{1}", points[i], pointAssigns[i]);
        }
    }

    private static double Distance(PointF p1, PointF p2)
    {
        double pow2X = Math.Pow(p1.X - p2.X, 2);
        double pow2Y = Math.Pow(p1.Y - p2.Y, 2);
        return Math.Sqrt(pow2X + pow2Y);
    }
    
    private static PointF CalcMeans(Point[] points, int[] pointAssigns, int j)
    {
        PointF mean = new PointF();
        int n = 0;
        for (int i = 0; i < points.Length; i++)
        {
            if (pointAssigns[i] == j)
            {
                mean.X += points[i].X;
                mean.Y += points[i].Y;
                n++;
            }
        }
        mean.X /= (float)n;
        mean.Y /= (float)n;
        return mean;
    }

    private static bool Compare(PointF a, PointF b)
    {
        if ((Math.Abs(a.X - b.X ) < 0.000000001) && (Math.Abs(a.Y  - b.Y  ) < 0.000000001))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    #region 打印数据(print datas)
    /// <summary>
    /// 打印初始数据
    /// </summary>
    private  void PrintInit(Point[] points, int k, PointF[] means)
    {
        Response.Write("总共" +  points.Length.ToString() +"个样本:");
        for (int i = 0; i < points.Length; i++)
        {
            Response.Write("(" + (points[i].X / 100000.0).ToString("#0.00000000") + "," + (points[i].Y / 100000.0).ToString("#0.00000000") + ")<br>");
        }
        Response.Write("---------------------------初始化时随机选取" + k.ToString() + "个样本作为聚类中心:--------------------<br><br>");
        for (int i = 0; i < k; i++)
        {
            Response.Write("聚类" + i.ToString() + "的中心: (" + (means[i].X / 100000.0).ToString("#0.00000000") + "," + (means[i].Y / 100000.0).ToString("#0.00000000") + ")<br>"); ;
        }
    }

    /// <summary>
    /// 打印迭代数据
    /// </summary>
    private  void PrintIter(Point[] points, int k, PointF[] means, int[] pointAssigns, int iter)
    {
        Response.Write( "-----------------------第" + iter.ToString() + " 次迭代的结果---------------------------<br>");
        for (int j = 0; j < k; j++)
        {
            Response.Write("第" + j.ToString() + " 个类的成员 <br>");            
            for (int i = 0; i < points.Length; i++)
            {
                if (pointAssigns[i] == j)
                {
                    Response.Write("(" + (points[i].X / 100000.0).ToString("#0.00000000") + "," + (points[i].Y / 100000.0).ToString("#0.00000000") + ")---");
                }
            }
            Response.Write("<br>均值(聚类中心): (" + (means[j].Y / 100000.0).ToString("#0.00000000") + "," + (means[j].X / 100000.0).ToString("#0.00000000") + " )<br>");
        }
    }
    #endregion
}
