﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
using System.Collections;

public partial class distributionplan : System.Web.UI.Page
{
    public double total_distance = double.MaxValue;
    public DataSet ds_jl = new DataSet();
    public DataSet ds_rk = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        loaddatapopu();
        loaddatadistance();
    }

    protected void loaddatapopu()
    {
        string mypath = Server.MapPath("app_data/") + "人口.xls";
        OleDbConnection conn2 = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Jet OLEDB:Database Password=;Extended properties=Excel 5.0;Data Source=" + mypath);
        string sql = "SELECT * FROM [Sheet1$]";
        conn2.Open();
        OleDbDataAdapter ad = new OleDbDataAdapter(sql, conn2);
        ad.Fill(ds_rk, "rk");
        conn2.Close();
    }

    protected void loaddatadistance()
    {
        string mypath = Server.MapPath("app_data/") + "距离.xls";
        OleDbConnection conn2 = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Jet OLEDB:Database Password=;Extended properties=Excel 5.0;Data Source=" + mypath);
        string sql = "SELECT * FROM [Sheet$]";
        conn2.Open();
        OleDbDataAdapter ad = new OleDbDataAdapter(sql, conn2);
        ad.Fill(ds_jl, "juli");
        conn2.Close();
    }

    //计算任意两个点之间的行车距离
    protected double distance(int i, int j, DataSet ds)
    {
        double jg = double.MaxValue;
        if (i < ds.Tables[0].Rows.Count && j < ds.Tables[0].Columns.Count)
        {
            jg = (double)(Convert.ToDouble(ds.Tables[0].Rows[i][j].ToString()) / 1000);
        }
        return jg;
    }

    //计算人口密度下的货物重量
    protected double popuweight(int i, DataSet ds)
    {
        double jg = 0;
        if (i < ds.Tables[0].Rows.Count && ds.Tables[0].Columns.Count > 0)
            jg = Convert.ToDouble(ds.Tables[0].Rows[i][8].ToString());
        return jg;
    }
    //计算人口密度下的货物重量
    protected double popuweight_wd(int i, DataSet ds)
    {
        double jg = 0;
        if (i < ds.Tables[0].Rows.Count && ds.Tables[0].Columns.Count > 0)
            jg = Convert.ToDouble(ds.Tables[0].Rows[i][1].ToString()) * Convert.ToDouble(ds.Tables[0].Rows[i][8].ToString());
        return jg;
    }

    protected double popuweight_jd(int i, DataSet ds)
    {
        double jg = 0;
        if (i < ds.Tables[0].Rows.Count && ds.Tables[0].Columns.Count > 0)
            jg = Convert.ToDouble(ds.Tables[0].Rows[i][2].ToString()) * Convert.ToDouble(ds.Tables[0].Rows[i][8].ToString());
        return jg;
    }

    protected double popuweight_m(DataSet ds)
    {
        double jg = 0;
        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            jg += Convert.ToDouble(ds.Tables[0].Rows[i][8].ToString());
        return jg;
    }

    //计算质心经纬度.
    protected double weight_sum_zhixin_jd(DataSet ds_rk)
    {
        double jg = 0;
        for (int j = 0; j < ds_rk.Tables[0].Rows.Count; j++)
        {
            jg = jg + popuweight_jd(j, ds_rk);
        }
        jg = jg / popuweight_m(ds_rk);
        return jg;
    }
    protected double weight_sum_zhixin_wd(DataSet ds_rk)
    {
        double jg = 0;

        for (int j = 0; j < ds_rk.Tables[0].Rows.Count; j++)
        {
            jg = jg + popuweight_wd(j, ds_rk);
        }

        jg = jg / popuweight_m(ds_rk);
        return jg;
    }

    //选择任意一个已知点到其他点之间的距离与人口密度之乘积，计算总和.
    protected double weight_sum(int i, DataSet ds_jl, DataSet ds_rk)
    {
        double jg = 0;
        if (i < ds_jl.Tables[0].Rows.Count && ds_jl.Tables[0].Columns.Count > 0)
        {
            for (int j = 2; j < ds_jl.Tables[0].Columns.Count; j++)
            {
                jg += distance(i, j, ds_jl) * popuweight(i, ds_rk);
            }
        }
        return jg;
    }
    //计算各个点的最短距离，获得一个数据列表，准备比较大小
    protected SortedList<int, double> weight_list(DataSet ds_jl, DataSet ds_rk)
    {
        SortedList<int, double> s = new SortedList<int, double>();
        for (int i = 0; i < ds_rk.Tables[0].Rows.Count; i++)
        {
            s.Add(i, weight_sum(i, ds_jl, ds_rk));
        }
        return s;
    }

    //找出到各点中最小总重量的点序号和总重量，排序
    protected double[,] weight_sort(SortedList<int, double> t)
    {
        SortedList<int, double> tmp_s = new SortedList<int, double>();
        for (int j = 0; j < t.Count; j++)
        {
            tmp_s.Add(t.Keys[j], t.Values[j]);
        }
        double[,] a = new double[t.Count, 2];
        for (int i = 0; i < t.Count; i++)
        {
            a[i, 0] = t.Keys[i];
            a[i, 1] = t.Values[i];
        }

        double[,] b = Sort(a, 1, "ASC");

        double tmp_v = double.MaxValue;
        for (int i = 0; i <= tmp_s.Count - 1; i++)
        {
            tmp_v = tmp_s.Values[i];
            for (int k = i + 1; k < tmp_s.Count; k++)
            {
                if (tmp_v > tmp_s.Values[k])
                {
                    SortedList<int, double> tt = new SortedList<int, double>();
                    tt.Add(tmp_s.Keys[k], tmp_s.Values[k]);

                    if (tmp_s.ContainsKey(tt.Keys[0]))
                    {
                        tmp_s[i] = tmp_s[k];
                        tmp_s.RemoveAt(k);
                        tmp_s.Add(tt.Keys[0], tt.Values[0]); 
                    }
                    else
                    {
                        tmp_s.Add(tt.Keys[0], tt.Values[0]);
                    }
                }
            }
            Response.Write(i.ToString() + "<br>");
        }

        return b;
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        double[,] a = new double[ds_jl.Tables[0].Rows.Count, 2];
        a = weight_sort(weight_list(ds_jl, ds_rk));
        for (int i = 0; i < a.GetLength(0); i++)
        {
            Response.Write(a[i, 0].ToString() + "----" + a[i, 1].ToString("#.#") + "<br>");
        }
    }

    private double[,] Sort<T>(T[,] array, int sortCol, string order)
    {
        int colCount = array.GetLength(1), rowCount = array.GetLength(0);
        if (sortCol >= colCount || sortCol < 0)
            throw new System.ArgumentOutOfRangeException("sortCol", "The column to sort on must be contained within the array bounds.");
        DataTable dt = new DataTable();
        // Name the columns with the second dimension index values, e.g., "0", "1", etc.
        for (int col = 0; col < colCount; col++)
        {
            DataColumn dc = new DataColumn(col.ToString(), typeof(T));
            dt.Columns.Add(dc);
        }
        // Load data into the data table:
        for (int rowindex = 0; rowindex < rowCount; rowindex++)
        {
            DataRow rowData = dt.NewRow();
            for (int col = 0; col < colCount; col++)
                rowData[col] = array[rowindex, col];
            dt.Rows.Add(rowData);
        }

        DataRow[] rows = dt.Select("", sortCol.ToString() + " " + order);
        double[,] a = new double[array.GetLength(0), 2];

        for (int row = 0; row <= rows.GetUpperBound(0); row++)
        {
            DataRow dr = rows[row];
            for (int col = 0; col < colCount; col++)
            {
                array[row, col] = (T)dr[col];
                a[row, col] = Convert.ToDouble((T)dr[col]);
            }
        }
        dt.Dispose();
        return a;
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        double jd = weight_sum_zhixin_jd(ds_rk);
        double wd = weight_sum_zhixin_wd(ds_rk);
        Response.Write(jd + "----------" + wd + "<br>");

        double[,] a = new double[ds_rk.Tables[0].Rows.Count, 2];
        for (int i = 0; i < ds_rk.Tables[0].Rows.Count; i++)
        {
            a[i, 0] = i;
            a[i, 1] = GetDistance(jd.ToString(), wd.ToString(), ds_rk.Tables[0].Rows[i][2].ToString(), ds_rk.Tables[0].Rows[i][1].ToString());
            // a[i,1] = 2 * Math.Asin(Convert.ToDouble(Math.Pow(Math.Pow(jd - Convert.ToDouble(ds_rk.Tables[0].Rows[i][2].ToString()), 2) +
            //  Math.Pow(wd - Convert.ToDouble(ds_rk.Tables[0].Rows[i][1].ToString()), 2), 0.5)));

        }
        double[,] b = new double[ds_rk.Tables[0].Rows.Count, 2];
        b = Sort(a, 1, "ASC");
        for (int i = 0; i < b.GetLength(0); i++)
            Response.Write(b[i, 0] + "----------" + Math.Round(b[i, 1], 2).ToString() + "<br>");
    }

    private const double EARTH_RADIUS = 6378.137;
    public double GetDistance(string lat1, string lng1, string lat2, string lng2)
    {
        double radLat1 = rad(Convert.ToDouble(lat1));
        double radLat2 = rad(Convert.ToDouble(lat2));
        double a = radLat1 - radLat2;
        double b = rad(Convert.ToDouble(lng1)) - rad(Convert.ToDouble(lng2));

        double s = 2 * Math.Asin(Math.Sqrt(Math.Pow(Math.Sin(a / 2), 2) +
        Math.Cos(radLat1) * Math.Cos(radLat2) * Math.Pow(Math.Sin(b / 2), 2)));
        s = s * EARTH_RADIUS;
        s = Math.Round(s * 10000) / 10000;
        return s;
    }

    private static double rad(double d)
    {
        return d * Math.PI / 180.0;
    } 
}

 